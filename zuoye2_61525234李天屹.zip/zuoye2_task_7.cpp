#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n = 0;
	float x;
	cout << "�������Ա���ֵ��";
	cin >> x;

	float sum = 0;
	float common = x;


	do {
		if (n > 0)
		{
			common = common * x * x * (2 * n - 1.0) * (-1) * (2 * n - 1.0) / ((2 * n + 1.0) * 2 * n);
		}

		sum = sum + common;


		n++;

	} while (fabs(common) > pow(10, -7));
	cout << "\narcsh" << x << "��ֵ��" << sum;
}

/*
float sum = 0;
	float common = 1;
	float fenzi = 1;
	float fenmu = 1;

	do {


		if (n == 0)
		{
			sum = sum + x;
		}

		else
		{
			for (int j = 1; j <= (2 * n - 1); j += 2)
			{
				fenzi = fenzi * j;
			}


			for (int i = 2; i <= (2 * n); i += 2)
			{
				fenmu = fenmu * i;
			}

			common = pow(-1, n) * (fenzi / fenmu) * pow(x, (2 * n+1)) / (2 * n + 1);
			sum = sum + common;
		}





		n++;

	} while (fabs(common) > pow(10, -7));



	float sum = 0;
	float common = x;


	do {
		if (n > 0)
		{
			common = common * x * x * (2 * n - 1.0)  * (-1) * (2 * n - 1.0) / ((2 * n + 1.0) * 2 * n);
		}

		sum = sum + common;


		n++;

	} while (fabs(common) > pow(10, -7));
	cout <<"\narcsh"<<x<<"��ֵ��"<< sum;



*/