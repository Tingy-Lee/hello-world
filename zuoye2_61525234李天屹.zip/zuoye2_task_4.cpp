#include<iostream>
using namespace std;
int main()
{
	
	
	for (int i = 4; i >= 0; i--)
	{
		for (int j = 1; j <= i; j++)
		{
			cout << " ";
		}



		int k = 9 - 2 * i - 2;
		cout << "*";
		if (k > 0)
		{
			for (int m = 1; m <= k; m++)
			{
				cout << " ";
			}
			cout << "*";
		}
		
		cout << endl;
		if(i==0)
		{
			for (int m = 1;m<=4;m++)
			{
				for (int j = 1; j <= m; j++)
				{
					cout << " ";
				}
				cout << "*";
				int h = 9 - 2 * m - 2;
				if (h > 0)
				{
					for (int m = 1; m <= h; m++)
					{
						cout << " ";
					}
					cout << "*";
				}
				cout << endl;
			}
			

		}
	}

}