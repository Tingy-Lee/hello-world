#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n;
	cout << "����n�Ĵ�С" << endl;
	cin >> n;

	int x;
	cout << "����x�Ĵ�С" << endl;
	cin >> x;

	int sum = 0;

	for (int i = 1; i <= n; i++)
	{
		int num = 0;
		for(int j=1;j<=i;j++)
		{
			
			num += x * pow(10, j-1);
		}
		sum+= pow(-1, i - 1) * num;
	}
	cout << "���Ϊ" << sum;
}